import { browser, by, element } from 'protractor';
import { CreatePatientPage } from './create-patient.po';
import { PatientListPage } from './patient-list.po';
import { PatientDetailPage } from './patient-detail.po';

describe(" Test to create and verify an appointment ",  () => {

  let cpp: CreatePatientPage;
  let plp: PatientListPage;
  let pdl: PatientDetailPage;

  it (" should create a patient record first", () => {
    //below statement navigates to the new patient page  
     cpp.navigateTo();
    //below statement will assign the first name
    cpp.setFirstName("Larissa");
    //below statement will assign the last name
    cpp.setLastName("DCosta");
    //below statment will assign birthdate
    cpp.setBirthDate("1988-02-09");
    //below statemnt will click on submit button
    cpp.submitForm();   
    
    //verify that patient record is created.
    var result =  element(by.css('drp-patient-detail .title')).getText();
    expect(result).toEqual("DCosta, Larissa");

  });

   it ("should create an appointment", () => {
     //navigate to patient list page
     plp.navigateTo();

     // click on the above created patient record
     plp.selectPatientByName("Larissa", "DCosta");

     //clicking on schedule appointment
     element(by.partialLinkText('appointments')).click();

     //passing date
     element(by.id('date')).sendKeys("2019-01-04");

     // time
     element(by.id('time')).sendKeys("1700");

    //passing duration
    element(by.id('duration')).sendKeys("40");

    //click on button
    element(by.css('button[type="submit"]')).click();      
   });

   it ("should verify the appointment", () => {
    var result1 = element(by.css('drp-schedule-item. col-8 col-md-6 name')).getText();
    expect(result1).toEqual("DCosta, Larissa");
   });
});
