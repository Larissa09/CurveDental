export * from './patients-list.component';
export * from './patient-resolver';
export * from './patient-thumbnail.component';
export * from './patient.service';
export * from './patient-detail.component';
export * from './patient.model';
export * from './edit-patient.component';
